//
// GPIO_7seg : counting from 0 to 9999 and display on 7-segment LEDs
//
#include <stdio.h>
#include "NUC100Series.h"
#include "MCU_init.h"
#include "SYS_init.h"
#include "Seven_Segment.h"

void Show(int x)
{

}

int main(void)
{
		int i = 0;
		
		SYS_Init();
		OpenSevenSegment();
	
		PC4 = 0;
		PC5 = 0;	
		PC6 = 0;	
		PC7 = 0;
		CLK_SysTickDelay(1000000);

		while(1)
		{
			PC5 = 1;
			PE0 = 0;
			CLK_SysTickDelay(1000000);
			PC5 = 0;
			PE0 = 1;
			
			PC5 = 1;
			PE4 = 0;
			CLK_SysTickDelay(1000000);
			PC5 = 0;
			PE4 = 1;
			
			PC5 = 1;
			PE3 = 0;
			CLK_SysTickDelay(1000000);
			PC5 = 0;
			PE3 = 1;
			
			PC5 = 1;
			PE2 = 0;
			CLK_SysTickDelay(1000000);
			PC5 = 0;
			PE2 = 1;
			
			PC5 = 1;
			PE6 = 0;
			CLK_SysTickDelay(1000000);
			PC5 = 0;
			PE6 = 1;
			
			PC5 = 1;
			PE5 = 0;
			CLK_SysTickDelay(1000000);
			PC5 = 0;
			PE5 = 1;
		}
		
		/*while(1)
		{
			PC4 = 1;
			PE0 = 0;
			CLK_SysTickDelay(1000000);
			PC4 = 0;
			PE0 = 1;
		
			PC5 = 1;
			PE6 = 0;
			CLK_SysTickDelay(1000000);
			PC5 = 0;
			PE6 = 1;
		
			PC6 = 1;
			PE4 = 0;
			CLK_SysTickDelay(1000000);
			PC6 = 0;
			PE4 = 1;
		
			PC7 = 1;
			PE2 = 0;
			CLK_SysTickDelay(1000000);
			PC7 = 0;
			PE2 = 1;
		}*/

}